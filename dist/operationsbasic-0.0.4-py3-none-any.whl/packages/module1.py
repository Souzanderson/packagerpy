def multiply(x,y):
    return x*y

def divide(x,y):
    return x/y
